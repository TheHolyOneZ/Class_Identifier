document.addEventListener("DOMContentLoaded", () => {
    const greetButton = document.getElementById("greet") as HTMLButtonElement;
    const farewellButton = document.getElementById("farewell") as HTMLButtonElement;
    const nameInput = document.getElementById("name") as HTMLInputElement;

    greetButton.addEventListener("click", () => {
        const name = nameInput.value;
        alert(`Hello, ${name}! Welcome to TypeScript interactive programming.`);
    });

    farewellButton.addEventListener("click", () => {
        const name = nameInput.value;
        alert(`Goodbye, ${name}! Keep learning TypeScript.`);
    });
});
