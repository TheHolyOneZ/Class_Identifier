using System;
using System.Windows.Forms;

public class Example : Form {
    private TextBox nameTextBox;
    private Button greetButton, farewellButton;

    public Example() {
        Text = "C# Greeting GUI";
        Size = new System.Drawing.Size(400, 300);

        Label label = new Label();
        label.Text = "Enter your name:";
        label.Location = new System.Drawing.Point(10, 20);
        Controls.Add(label);

        nameTextBox = new TextBox();
        nameTextBox.Location = new System.Drawing.Point(150, 20);
        Controls.Add(nameTextBox);

        greetButton = new Button();
        greetButton.Text = "Greet";
        greetButton.Location = new System.Drawing.Point(10, 80);
        greetButton.Click += (sender, args) => {
            MessageBox.Show($"Hello, {nameTextBox.Text}! Welcome to C# programming.");
        };
        Controls.Add(greetButton);

        farewellButton = new Button();
        farewellButton.Text = "Farewell";
        farewellButton.Location = new System.Drawing.Point(150, 80);
        farewellButton.Click += (sender, args) => {
            MessageBox.Show($"Goodbye, {nameTextBox.Text}! Keep learning C#.");
        };
        Controls.Add(farewellButton);
    }

    public static void Main() {
        Application.Run(new Example());
    }
}
