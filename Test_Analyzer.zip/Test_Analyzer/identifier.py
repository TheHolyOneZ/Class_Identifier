# Cleaned by TheZ
import gc
import re
import json
import datetime
import threading
import queue
import ast
import esprima
import logging
import hashlib
import concurrent.futures
from pathlib import Path
from typing import Dict, Set, List
from dataclasses import dataclass, asdict
from rich.console import Console
from rich.table import Table
from rich.progress import Progress
from bs4 import BeautifulSoup
import networkx as nx
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor
import multiprocessing
from functools import lru_cache
import javalang


@dataclass
class ClassMetrics:
    complexity: int = 0
    lines_of_code: int = 0
    dependency_count: int = 0
    inheritance_depth: int = 0
    method_count: int = 0
    attribute_count: int = 0
    usage_count: int = 0


@dataclass
class ClassInfo:
    name: str
    file_type: str
    file_path: str
    metrics: ClassMetrics = None
    properties: Set[str] = None
    parent_classes: Set[str] = None
    methods: Dict[str, dict] = None
    attributes: Dict[str, str] = None
    usage_locations: Set[str] = None
    dependencies: Set[str] = None
    inline_styles: Set[str] = None
    event_handlers: Dict[str, List[str]] = None
    documentation: str = ""
    hash: str = ""

    def __post_init__(self):
        self.metrics = ClassMetrics() if self.metrics is None else self.metrics
        self.properties = set() if self.properties is None else self.properties
        self.parent_classes = (
            set() if self.parent_classes is None else self.parent_classes
        )
        self.methods = {} if self.methods is None else self.methods
        self.attributes = {} if self.attributes is None else self.attributes
        self.usage_locations = (
            set() if self.usage_locations is None else self.usage_locations
        )
        self.dependencies = set() if self.dependencies is None else self.dependencies
        self.inline_styles = set() if self.inline_styles is None else self.inline_styles
        self.event_handlers = {} if self.event_handlers is None else self.event_handlers
        self.calculate_hash()

    def calculate_hash(self):
        """Calculate unique hash for class content"""
        content = f"{self.name}{self.methods}{self.attributes}"
        self.hash = hashlib.sha256(content.encode()).hexdigest()


class PowerfulClassIdentifier:
    def __init__(self, max_workers: int = None):
        self.console = Console()
        self.classes: Dict[str, ClassInfo] = {}
        self.export_path = Path("class_analysis_results")
        self.export_path.mkdir(exist_ok=True)
        self.max_workers = max_workers or multiprocessing.cpu_count()
        self.file_queue = queue.Queue()
        self.result_lock = threading.Lock()
        self.setup_logging()
        self.class_graph = nx.DiGraph()
        self.processed_files: Set[str] = set()
        self.metrics_cache = {}

    def setup_logging(self):
        """Setup advanced logging"""
        logging.basicConfig(
            filename=self.export_path / "analysis.log",
            level=logging.INFO,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

    def extract_python_classes(
        self, content: str, filepath: str
    ) -> Dict[str, ClassInfo]:
        classes = {}
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    class_info = ClassInfo(
                        name=node.name, file_type="Python", file_path=filepath
                    )
                    for item in node.body:
                        if isinstance(item, ast.FunctionDef):
                            class_info.methods[item.name] = {
                                "args": [arg.arg for arg in item.args.args],
                                "decorators": [
                                    d.id
                                    for d in item.decorator_list
                                    if isinstance(d, ast.Name)
                                ],
                            }
                    for item in node.body:
                        if isinstance(item, ast.Assign):
                            for target in item.targets:
                                if isinstance(target, ast.Name):
                                    class_info.attributes[target.id] = ast.unparse(
                                        item.value
                                    )
                    class_content = ast.unparse(node)
                    class_info.metrics.complexity = self.calculate_complexity(
                        class_content
                    )
                    class_info.metrics.lines_of_code = len(class_content.splitlines())
                    classes[node.name] = class_info
            return classes
        except Exception as e:
            logging.error(f"Error parsing Python file {filepath}: {e}")
            return {}

    def extract_javascript_classes(
        self, content: str, filepath: str
    ) -> Dict[str, ClassInfo]:
        classes = {}
        try:
            ast = esprima.parseScript(content)

            def process_class_node(node):
                if node.type == "ClassDeclaration":
                    class_info = ClassInfo(
                        name=node.id.name, file_type="JavaScript", file_path=filepath
                    )
                    for method in node.body.body:
                        if method.type == "MethodDefinition":
                            class_info.methods[method.key.name] = {
                                "kind": method.kind,
                                "static": method.static,
                            }
                    if hasattr(node, "superClass") and node.superClass:
                        class_info.parent_classes.add(node.superClass.name)
                    class_info.metrics.complexity = self.calculate_complexity(str(node))
                    classes[node.id.name] = class_info

            def traverse(node):
                if isinstance(node, dict):
                    process_class_node(node)
                    for value in node.values():
                        traverse(value)
                elif isinstance(node, list):
                    for item in node:
                        traverse(item)

            traverse(ast.toDict())
            return classes
        except Exception as e:
            logging.error(f"Error parsing JavaScript file {filepath}: {e}")
            return {}

    def extract_html_classes(self, content: str, filepath: str) -> Dict[str, ClassInfo]:
        classes = {}
        try:
            soup = BeautifulSoup(content, "html.parser")
            elements_with_class = soup.find_all(class_=True)
            for element in elements_with_class:
                for class_name in element.get("class", []):
                    if class_name not in classes:
                        class_info = ClassInfo(
                            name=class_name, file_type="HTML", file_path=filepath
                        )
                        class_info.usage_locations.add(element.name)
                        if element.get("style"):
                            class_info.inline_styles.add(element["style"])
                        for attr in element.attrs:
                            if attr.startswith("on"):
                                if "event_handlers" not in class_info.methods:
                                    class_info.methods["event_handlers"] = {}
                                class_info.methods["event_handlers"][attr] = element[
                                    attr
                                ]
                        classes[class_name] = class_info
                    else:
                        classes[class_name].usage_locations.add(element.name)
            return classes
        except Exception as e:
            logging.error(f"Error parsing HTML file {filepath}: {e}")
            return {}

    def extract_css_classes(self, content: str, filepath: str) -> Dict[str, ClassInfo]:
        classes = {}
        try:
            class_pattern = r"\.([a-zA-Z0-9_-]+)\s*{([^}]*)}"
            for match in re.finditer(class_pattern, content):
                class_name = match.group(1)
                properties = match.group(2)
                class_info = ClassInfo(
                    name=class_name, file_type="CSS", file_path=filepath
                )
                for prop in properties.split(";"):
                    prop = prop.strip()
                    if prop:
                        class_info.properties.add(prop)
                media_pattern = r"@media[^{]+{[^}]*\." + class_name + r"[^}]+}"
                media_queries = re.findall(media_pattern, content)
                if media_queries:
                    class_info.properties.add("responsive")
                classes[class_name] = class_info
            return classes
        except Exception as e:
            logging.error(f"Error parsing CSS file {filepath}: {e}")
            return {}

    def extract_java_classes(self, content: str, filepath: str) -> Dict[str, ClassInfo]:
        classes = {}
        try:
            tree = javalang.parse.parse(content)
            for path, node in tree.filter(javalang.tree.ClassDeclaration):
                class_info = ClassInfo(
                    name=node.name, file_type="Java", file_path=filepath
                )
                for method in node.methods:
                    class_info.methods[method.name] = {
                        "return_type": str(method.return_type),
                        "modifiers": list(method.modifiers),
                    }
                for field in node.fields:
                    for declarator in field.declarators:
                        class_info.attributes[declarator.name] = str(field.type)
                if node.extends:
                    class_info.parent_classes.add(str(node.extends.name))
                classes[node.name] = class_info
            return classes
        except Exception as e:
            logging.error(f"Error parsing Java file {filepath}: {e}")
            return {}

    def read_file_in_chunks(self, filepath: str, chunk_size=8192):
        with open(filepath, "r", encoding="utf-8") as file:
            while True:
                chunk = file.read(chunk_size)
                if not chunk:
                    break
                yield chunk

    def process_file(self, filepath: str):
        try:
            content = []
            total_size = Path(filepath).stat().st_size
            if total_size > 10 * 1024 * 1024:  # Files larger than 10MB
                for chunk in self.read_file_in_chunks(filepath):
                    content.append(chunk)
                content = "".join(content)
            else:
                with open(filepath, "r", encoding="utf-8") as f:
                    content = f.read()
            if len(content) > 1_000_000:  # 1MB threshold
                classes = {}
                batch_size = 500_000  # Process 500KB at a time
                for i in range(0, len(content), batch_size):
                    batch = content[i : i + batch_size]
                    classes.update(self.process_file_content(filepath, batch))
            else:
                classes = self.process_file_content(filepath, content)
            with self.result_lock:
                self.classes.update(classes)
                self.processed_files.add(filepath)
                for class_name, info in classes.items():
                    self.class_graph.add_node(class_name)
                    for parent in info.parent_classes:
                        self.class_graph.add_edge(class_name, parent)
        except Exception as e:
            logging.error(f"Error processing file {filepath}: {e}")

    @lru_cache(maxsize=1000)
    def calculate_complexity(self, code: str) -> int:
        """Calculate cyclomatic complexity"""
        return len(re.findall(r"\b(if|while|for|and|or)\b", code))

    def scan_directory(self, path: str) -> List[str]:
        """Recursively scan directory for supported files"""
        supported_extensions = {
            ".py",
            ".java",
            ".js",
            ".html",
            ".css",
            ".jsx",
            ".tsx",
            ".ts",
        }
        files = []
        path = Path(path)
        try:
            if path.is_file():
                if path.suffix in supported_extensions:
                    files.append(str(path))
            else:
                for item in path.rglob("*"):
                    if item.is_file() and item.suffix in supported_extensions:
                        files.append(str(item))
            logging.info(f"Found {len(files)} files in {path}")
            return files
        except Exception as e:
            logging.error(f"Error scanning directory {path}: {e}")
            return []

    def process_file_content(
        self, file_path: str, content: str
    ) -> Dict[str, ClassInfo]:
        """Process file content based on file type"""
        suffix = Path(file_path).suffix.lower()
        processors = {
            ".py": self.extract_python_classes,
            ".js": self.extract_javascript_classes,
            ".jsx": self.extract_javascript_classes,
            ".tsx": self.extract_javascript_classes,
            ".ts": self.extract_javascript_classes,
            ".html": self.extract_html_classes,
            ".css": self.extract_css_classes,
            ".java": self.extract_java_classes,
        }
        processor = processors.get(suffix)
        if processor:
            return processor(content, file_path)
        return {}

    def analyze_files_threaded(self, files: List[str]):
        """Analyze files using thread pool with memory management"""
        batch_size = 10  # Process 10 files at a time
        with Progress() as progress:
            task = progress.add_task("[cyan]Processing files...", total=len(files))
            for i in range(0, len(files), batch_size):
                batch = files[i : i + batch_size]
                with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                    futures = {
                        executor.submit(self.process_file, file): file for file in batch
                    }
                    for completed in concurrent.futures.as_completed(futures):
                        file = futures[completed]
                        try:
                            completed.result()
                        except Exception as e:
                            logging.error(f"Error processing {file}: {e}")
                        progress.update(task, advance=1)
                        gc.collect()

    def generate_comprehensive_report(self):
        """Generate comprehensive analysis report"""
        report = {
            "summary": {
                "total_classes": len(self.classes),
                "total_files": len(self.processed_files),
                "analysis_timestamp": datetime.datetime.now().isoformat(),
            },
            "metrics": {
                "average_complexity": (
                    sum(c.metrics.complexity for c in self.classes.values())
                    / len(self.classes)
                    if self.classes
                    else 0
                ),
                "total_lines": sum(
                    c.metrics.lines_of_code for c in self.classes.values()
                ),
                "inheritance_depth_max": (
                    max(c.metrics.inheritance_depth for c in self.classes.values())
                    if self.classes
                    else 0
                ),
            },
            "classes": {name: asdict(info) for name, info in self.classes.items()},
        }
        return report

    class CustomJSONEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, set):
                return list(obj)
            if isinstance(obj, datetime.datetime):
                return obj.isoformat()
            return super().default(obj)

    def export_results(self):
        """Export analysis results in multiple formats"""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        report = self.generate_comprehensive_report()
        with open(self.export_path / f"analysis_{timestamp}.json", "w") as f:
            json.dump(report, f, indent=2, cls=self.CustomJSONEncoder)
        self.generate_visualization(timestamp)
        self.generate_html_report(report, timestamp)
        logging.info(f"Results exported successfully at {timestamp}")

    def generate_visualization(self, timestamp: str):
        """Generate visual representations of the analysis"""
        plt.figure(figsize=(15, 10))
        pos = nx.spring_layout(self.class_graph)
        nx.draw(
            self.class_graph,
            pos,
            with_labels=True,
            node_color="lightblue",
            node_size=2000,
            font_size=8,
            font_weight="bold",
        )
        plt.savefig(self.export_path / f"class_graph_{timestamp}.png")
        plt.close()

    def generate_html_report(self, report: dict, timestamp: str):
        """Generate interactive HTML report"""
        template = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Class Analysis Report</title>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
            <style>
                /* Add your CSS styles here */
            </style>
        </head>
        <body>
            <!-- Add your HTML template here -->
        </body>
        </html>
        """


def main():
    identifier = PowerfulClassIdentifier()
    console = Console()
    console.print("[bold blue]🚀 Super Powerful Class Identifier v3.0[/bold blue]")
    console.print(
        "[green]Enter file or folder paths (one per line, press Enter twice to finish):[/green]"
    )
    files = []
    while True:
        path_input = input().strip()
        if not path_input:
            break
        files.extend(identifier.scan_directory(path_input))
    if files:
        console.print(f"[cyan]Found {len(files)} files to analyze[/cyan]")
        identifier.analyze_files_threaded(files)
        identifier.export_results()
        table = Table(title="Analysis Summary")
        table.add_column("Class Name", style="cyan")
        table.add_column("Type", style="magenta")
        table.add_column("Complexity", style="red")
        table.add_column("Dependencies", style="yellow")
        for class_name, info in identifier.classes.items():
            table.add_row(
                class_name,
                info.file_type,
                str(info.metrics.complexity),
                ", ".join(info.dependencies) if info.dependencies else "None",
            )
        console.print(table)
        console.print(
            "\n[green]✨ Analysis complete! Results exported to 'class_analysis_results' folder![/green]"
        )
    else:
        console.print("[red]No files found to analyze![/red]")


if __name__ == "__main__":
    main()

# End of cleanup by TheZ