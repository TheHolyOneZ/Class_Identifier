document.addEventListener("DOMContentLoaded", () => {
    const greetButton = document.getElementById("greet");
    const farewellButton = document.getElementById("farewell");
    const nameInput = document.getElementById("name");

    greetButton.addEventListener("click", () => {
        const name = nameInput.value;
        alert(`Hello, ${name}! Welcome to JavaScript interactive programming.`);
    });

    farewellButton.addEventListener("click", () => {
        const name = nameInput.value;
        alert(`Goodbye, ${name}! Keep learning JavaScript.`);
    });
});
