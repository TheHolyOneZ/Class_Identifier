import javax.swing.*;

public class Example {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Java Greeting GUI");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Enter your name:");
        userLabel.setBounds(10, 20, 160, 25);
        panel.add(userLabel);

        JTextField userText = new JTextField(20);
        userText.setBounds(180, 20, 165, 25);
        panel.add(userText);

        JButton greetButton = new JButton("Greet");
        greetButton.setBounds(10, 80, 150, 25);
        greetButton.addActionListener(e -> JOptionPane.showMessageDialog(null, 
            "Hello, " + userText.getText() + "! Welcome to Java GUI programming."));
        panel.add(greetButton);

        JButton farewellButton = new JButton("Farewell");
        farewellButton.setBounds(180, 80, 150, 25);
        farewellButton.addActionListener(e -> JOptionPane.showMessageDialog(null, 
            "Goodbye, " + userText.getText() + "! Keep learning Java."));
        panel.add(farewellButton);
    }
}
