import tkinter as tk
from tkinter import messagebox

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Python Greeting GUI")

        self.label = tk.Label(root, text="Enter your name:")
        self.label.pack()

        self.name_entry = tk.Entry(root)
        self.name_entry.pack()

        self.greet_button = tk.Button(root, text="Greet", command=self.greet)
        self.greet_button.pack()

        self.farewell_button = tk.Button(root, text="Farewell", command=self.farewell)
        self.farewell_button.pack()

    def greet(self):
        name = self.name_entry.get()
        messagebox.showinfo("Greeting", f"Hello, {name}! Welcome to Python GUI programming.")

    def farewell(self):
        name = self.name_entry.get()
        messagebox.showinfo("Farewell", f"Goodbye, {name}! Keep learning Python.")

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
