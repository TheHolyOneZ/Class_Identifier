#include <iostream>
#include <string>

int main() {
    std::string name;
    std::cout << "Enter your name: ";
    std::getline(std::cin, name);

    std::cout << "Hello, " << name << "! Welcome to the C++ console app.
";
    std::cout << "Goodbye, " << name << "! Keep learning C++.
";
    return 0;
}
