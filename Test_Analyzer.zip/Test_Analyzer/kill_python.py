import os
import signal
import psutil
import time

def force_kill_python():
    print("🔥 INITIATING FORCE KILL SEQUENCE 🔥")
    killed = 0
    
    for proc in psutil.process_iter(['pid', 'name', 'status']):
        try:
            if 'python' in proc.info['name'].lower():
                # Try SIGTERM first
                os.kill(proc.info['pid'], signal.SIGTERM)
                time.sleep(0.1)
                
                # If process still exists, use SIGKILL
                if psutil.pid_exists(proc.info['pid']):
                    os.kill(proc.info['pid'], signal.SIGKILL)
                
                killed += 1
                print(f"💀 Terminated: {proc.info['name']} (PID: {proc.info['pid']})")
        except:
            continue

    print(f"\n✅ Total Python processes eliminated: {killed}")
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    force_kill_python()
