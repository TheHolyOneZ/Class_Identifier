# Cleaned by TheZ
import pstats
import re
import json
import datetime
import threading
import queue
import ast
import esprima
import logging
import hashlib
import concurrent.futures
from pathlib import Path
from typing import Dict, Set, Any, List
from dataclasses import dataclass
from rich.console import Console
import networkx as nx
import matplotlib.pyplot as plt
from concurrent.futures import ThreadPoolExecutor
import multiprocessing
import javalang
from radon.metrics import mi_visit
from radon.complexity import cc_visit
from pytype import config
import memory_profiler
import cProfile
from mccabe import McCabeChecker
from coverage import Coverage
from mypy import api as mypy_api
from prospector.run import Prospector
from vulture.core import Vulture
from bandit.core.config import BanditConfig
from bandit.core.manager import BanditManager
import seaborn as sns
import numpy as np
from jinja2 import Template
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Image
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Image,
)
import sys

sys.setrecursionlimit(10000)
from rich.progress import Progress
from reportlab.platypus import Table, TableStyle, Spacer, Paragraph
from reportlab.lib import colors
import matplotlib.pyplot as plt
import networkx as nx


@dataclass
class AdvancedMetrics:
    complexity: int = 0
    lines_of_code: int = 0
    maintainability_index: float = 0
    test_coverage: float = 0
    security_score: int = 0
    memory_usage: float = 0
    performance_score: float = 0
    dependency_count: int = 0
    inheritance_depth: int = 0
    method_count: int = 0
    attribute_count: int = 0
    usage_count: int = 0
    code_smells: List[str] = None
    dead_code_percentage: float = 0
    documentation_coverage: float = 0
    type_safety_score: float = 0
    cyclomatic_complexity: int = 0
    cognitive_complexity: int = 0
    halstead_metrics: Dict[str, float] = None
    fan_in: int = 0
    fan_out: int = 0
    instability: float = 0
    abstractness: float = 0
    efferent_coupling: int = 0
    afferent_coupling: int = 0

    def __post_init__(self):
        self.code_smells = [] if self.code_smells is None else self.code_smells
        self.halstead_metrics = (
            {} if self.halstead_metrics is None else self.halstead_metrics
        )
        self.calculate_derived_metrics()

    def calculate_derived_metrics(self):
        if self.fan_in + self.fan_out > 0:
            self.instability = self.fan_out / (self.fan_in + self.fan_out)
        self.calculate_coupling_metrics()

    def calculate_coupling_metrics(self):
        self.efferent_coupling = len(set(self.code_smells))
        self.update_complexity_metrics()

    def update_complexity_metrics(self):
        self.complexity = max(self.cyclomatic_complexity, self.cognitive_complexity)


@dataclass
class SecurityMetrics:
    vulnerabilities: List[Dict[str, Any]] = None
    security_score: int = 100
    critical_issues: int = 0
    high_issues: int = 0
    medium_issues: int = 0
    low_issues: int = 0

    def __post_init__(self):
        self.vulnerabilities = (
            [] if self.vulnerabilities is None else self.vulnerabilities
        )
        self.calculate_security_metrics()

    def calculate_security_metrics(self):
        for vuln in self.vulnerabilities:
            severity = vuln.get("severity", "LOW").upper()
            if severity == "CRITICAL":
                self.critical_issues += 1
                self.security_score -= 10
            elif severity == "HIGH":
                self.high_issues += 1
                self.security_score -= 5
            elif severity == "MEDIUM":
                self.medium_issues += 1
                self.security_score -= 3
            elif severity == "LOW":
                self.low_issues += 1
                self.security_score -= 1
        self.security_score = max(0, self.security_score)


@dataclass
class PerformanceMetrics:
    execution_time: float = 0.0
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    io_operations: int = 0
    network_calls: int = 0
    database_queries: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    bottlenecks: List[str] = None

    def __post_init__(self):
        self.bottlenecks = [] if self.bottlenecks is None else self.bottlenecks
        self.calculate_performance_score()

    def calculate_performance_score(self):
        self.performance_score = 100
        if self.execution_time > 1.0:
            self.performance_score -= 10
        if self.memory_usage > 100:
            self.performance_score -= 10
        if self.cpu_usage > 80:
            self.performance_score -= 10
        if len(self.bottlenecks) > 0:
            self.performance_score -= len(self.bottlenecks) * 5


@dataclass
class CodeQualityMetrics:
    maintainability_index: float = 0.0
    test_coverage: float = 0.0
    documentation_coverage: float = 0.0
    code_duplication: float = 0.0
    naming_convention_violations: int = 0
    style_violations: int = 0
    type_safety_score: float = 0.0

    def calculate_quality_score(self):
        weights = {
            "maintainability": 0.3,
            "test_coverage": 0.2,
            "documentation": 0.15,
            "duplication": 0.15,
            "naming": 0.1,
            "style": 0.1,
        }
        return (
            weights["maintainability"] * self.maintainability_index
            + weights["test_coverage"] * self.test_coverage
            + weights["documentation"] * self.documentation_coverage
            + weights["duplication"] * (100 - self.code_duplication)
            + weights["naming"] * (100 - self.naming_convention_violations)
            + weights["style"] * (100 - self.style_violations)
        )


@dataclass
class EnhancedClassInfo:
    name: str
    file_type: str
    file_path: str
    metrics: AdvancedMetrics = None
    security_metrics: SecurityMetrics = None
    performance_metrics: PerformanceMetrics = None
    quality_metrics: CodeQualityMetrics = None
    properties: Set[str] = None
    parent_classes: Set[str] = None
    methods: Dict[str, dict] = None
    attributes: Dict[str, str] = None
    usage_locations: Set[str] = None
    dependencies: Set[str] = None
    api_endpoints: Dict[str, str] = None
    security_vulnerabilities: List[str] = None
    performance_bottlenecks: List[str] = None
    test_cases: Dict[str, List[str]] = None
    code_quality_metrics: Dict[str, float] = None
    type_annotations: Dict[str, str] = None
    async_operations: Set[str] = None
    documentation: str = ""
    hash: str = ""
    inline_styles: Set[str] = None
    event_handlers: Dict[str, List[str]] = None
    design_patterns: Set[str] = None
    code_smells: Set[str] = None
    refactoring_suggestions: List[str] = None

    def __post_init__(self):
        self.initialize_attributes()
        self.calculate_hash()
        self.analyze_patterns()

    def initialize_attributes(self):
        self.metrics = AdvancedMetrics() if self.metrics is None else self.metrics
        self.security_metrics = (
            SecurityMetrics()
            if self.security_metrics is None
            else self.security_metrics
        )
        self.performance_metrics = (
            PerformanceMetrics()
            if self.performance_metrics is None
            else self.performance_metrics
        )
        self.quality_metrics = (
            CodeQualityMetrics()
            if self.quality_metrics is None
            else self.quality_metrics
        )
        self.properties = set() if self.properties is None else self.properties
        self.parent_classes = (
            set() if self.parent_classes is None else self.parent_classes
        )
        self.methods = {} if self.methods is None else self.methods
        self.attributes = {} if self.attributes is None else self.attributes
        self.usage_locations = (
            set() if self.usage_locations is None else self.usage_locations
        )
        self.dependencies = set() if self.dependencies is None else self.dependencies
        self.api_endpoints = {} if self.api_endpoints is None else self.api_endpoints
        self.security_vulnerabilities = (
            []
            if self.security_vulnerabilities is None
            else self.security_vulnerabilities
        )
        self.performance_bottlenecks = (
            [] if self.performance_bottlenecks is None else self.performance_bottlenecks
        )
        self.test_cases = {} if self.test_cases is None else self.test_cases
        self.code_quality_metrics = (
            {} if self.code_quality_metrics is None else self.code_quality_metrics
        )
        self.type_annotations = (
            {} if self.type_annotations is None else self.type_annotations
        )
        self.async_operations = (
            set() if self.async_operations is None else self.async_operations
        )
        self.inline_styles = set() if self.inline_styles is None else self.inline_styles
        self.event_handlers = {} if self.event_handlers is None else self.event_handlers
        self.design_patterns = (
            set() if self.design_patterns is None else self.design_patterns
        )
        self.code_smells = set() if self.code_smells is None else self.code_smells
        self.refactoring_suggestions = (
            [] if self.refactoring_suggestions is None else self.refactoring_suggestions
        )

    def calculate_hash(self):
        content = f"{self.name}{self.methods}{self.attributes}{self.dependencies}"
        self.hash = hashlib.sha256(content.encode()).hexdigest()

    def _check_feature_envy(self) -> bool:
        external_calls = 0
        internal_calls = 0
        for method in self.methods.values():
            if isinstance(method, dict) and "calls" in method:
                for call in method["calls"]:
                    if call in self.methods:
                        internal_calls += 1
                    else:
                        external_calls += 1
        return external_calls > internal_calls * 2

    def analyze_patterns(self):
        self.detect_design_patterns()
        self.detect_code_smells()
        self.generate_refactoring_suggestions()

    def detect_design_patterns(self) -> Set[str]:
        """Detect design patterns in class"""
        patterns = set()
        if hasattr(self, "methods"):
            if any("getInstance" in method for method in self.methods):
                patterns.add("singleton")
            if any("create" in method.lower() for method in self.methods):
                patterns.add("factory")
            observer_methods = {"notify", "update", "subscribe"}
            if any(method in observer_methods for method in self.methods):
                patterns.add("observer")
            if self.parent_classes and len(self.parent_classes) > 0:
                patterns.add("decorator")
            if any("strategy" in method.lower() for method in self.methods):
                patterns.add("strategy")
        return patterns

    def _check_long_methods(self) -> bool:
        long_method_threshold = 50  # lines
        return any(
            isinstance(method, dict) and method.get("lines", 0) > long_method_threshold
            for method in self.methods.values()
        )

    def _check_duplicate_code(self) -> bool:
        """Check for duplicate code within methods"""
        method_contents = {}
        for method_name, method_info in self.methods.items():
            if isinstance(method_info, dict):
                content = str(method_info.get("body", ""))
                if content in method_contents.values():
                    return True
                method_contents[method_name] = content
        return False

    def _check_singleton_pattern(self) -> bool:
        has_private_constructor = any(
            method.get("visibility") == "private" and method.get("name") == "__init__"
            for method in self.methods.values()
        )
        has_instance_method = any(
            "getInstance" in method or "get_instance" in method
            for method in self.methods.keys()
        )
        return has_private_constructor and has_instance_method

    def _check_factory_pattern(self) -> bool:
        return any(
            "create" in method or "factory" in method.lower()
            for method in self.methods.keys()
        )

    def _check_observer_pattern(self) -> bool:
        observer_methods = {"notify", "update", "subscribe", "unsubscribe"}
        return any(method in self.methods for method in observer_methods)

    def _check_decorator_pattern(self) -> bool:
        return any(
            hasattr(method, "decorators") and method.decorators
            for method in self.methods.values()
        )

    def _check_strategy_pattern(self) -> bool:
        return len(self.parent_classes) > 0 and any(
            "strategy" in method.lower() for method in self.methods.keys()
        )

    def detect_code_smells(self):
        smell_detectors = {
            "god_class": self._check_god_class,
            "data_class": self._check_data_class,
            "feature_envy": self._check_feature_envy,
            "long_method": self._check_long_methods,
            "duplicate_code": self._check_duplicate_code,
        }
        for smell, detector in smell_detectors.items():
            if detector():
                self.code_smells.add(smell)

    def _check_god_class(self) -> bool:
        return (
            len(self.methods) > 20
            or self.metrics.complexity > 50
            or len(self.attributes) > 15
        )

    def _check_data_class(self) -> bool:
        return len(self.attributes) > 0 and all(
            method.startswith(("get_", "set_")) for method in self.methods.keys()
        )

    def generate_refactoring_suggestions(self):
        if "god_class" in self.code_smells:
            self.refactoring_suggestions.append(
                "Consider splitting this class into smaller, more focused classes"
            )
        if "data_class" in self.code_smells:
            self.refactoring_suggestions.append(
                "Consider adding behavior to this class or converting it to a data structure"
            )
        if self.metrics.complexity > 30:
            self.refactoring_suggestions.append(
                "High complexity detected. Consider extracting methods or using design patterns"
            )


class UltimatePowerClassAnalyzer:
    def __init__(self, max_workers: int = None):
        self.console = Console()
        self.classes: Dict[str, EnhancedClassInfo] = {}
        self.export_path = Path("advanced_analysis_results")
        self.export_path.mkdir(exist_ok=True)
        self.max_workers = max_workers or multiprocessing.cpu_count()
        self.file_queue = queue.Queue()
        self.result_lock = threading.Lock()
        self.class_graph = nx.DiGraph()
        self.dependency_graph = nx.DiGraph()
        self.metrics_cache = {}
        bandit_config = BanditConfig()
        self.security_scanner = BanditManager(bandit_config, "file")
        self.type_checker_config = config.Options.create([])
        self.profiler = cProfile.Profile()
        self.setup_advanced_logging()
        self.performance_metrics = {}
        self.vulnerability_database = set()
        self.pattern_database = self.load_pattern_database()
        self.code_quality_analyzer = self.initialize_code_quality_analyzer()
        self.test_coverage_analyzer = Coverage()
        self.memory_profiler = memory_profiler.profile
        self.thread_pool = ThreadPoolExecutor(max_workers=self.max_workers)
        self.analysis_start_time = datetime.datetime.now()

    def convert_dict_to_class_info(self, class_dict):
        return EnhancedClassInfo(
            name=class_dict.get("name", ""),
            file_type=class_dict.get("file_type", ""),
            file_path=class_dict.get("file_path", ""),
            metrics=(
                AdvancedMetrics(**class_dict.get("metrics", {}))
                if class_dict.get("metrics")
                else None
            ),
            security_metrics=(
                SecurityMetrics(**class_dict.get("security_metrics", {}))
                if class_dict.get("security_metrics")
                else None
            ),
        )

    def initialize_code_quality_analyzer(self):
        from prospector.config import ProspectorConfig
        import ast

        dummy_tree = ast.parse("")
        dummy_filename = "<dummy>"
        prospector_config = ProspectorConfig()
        prospector_config.messages = []
        return {
            "prospector": Prospector(prospector_config),
            "vulture": Vulture(),
            "mccabe": McCabeChecker(dummy_tree, dummy_filename),
            "mypy": mypy_api,
        }

    def analyze_file(self, file_path: Path) -> None:
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                content = f.read()
            file_extension = file_path.suffix.lower()
            results = {}
            if file_extension == ".py":
                results = self.analyze_file_content(str(file_path), content)
            elif file_extension == ".java":
                results = self.analyze_java_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".js":
                results = self.analyze_javascript_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".ts":
                results = self.analyze_typescript_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".cpp":
                results = self.analyze_cpp_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".cs":
                results = self.analyze_csharp_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".html":
                results = self.analyze_html_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            elif file_extension == ".css":
                results = self.analyze_css_content(content) or {
                    "classes": {},
                    "metrics": {},
                }
            self.classes.update(results.get("classes", {}))
            self.metrics_cache[str(file_path)] = {
                "metrics": results.get("metrics", {}),
                "security": results.get("security", {}),
                "performance": results.get("performance", {}),
                "quality": results.get("quality", {}),
            }
            logging.info(f"Successfully analyzed {file_path}")
        except Exception as e:
            logging.error(f"Error analyzing {file_path}: {str(e)}")
            raise

    def collect_metrics_data(self) -> List[Dict[str, float]]:
        metrics_data = []
        for class_info in self.classes.values():
            metrics_dict = {
                "complexity": class_info.metrics.complexity,
                "security_score": (
                    class_info.security_metrics.security_score
                    if class_info.security_metrics
                    else 0
                ),
                "performance_score": (
                    class_info.performance_metrics.performance_score
                    if hasattr(class_info.performance_metrics, "performance_score")
                    else 0
                ),
                "code_quality": (
                    class_info.quality_metrics.calculate_quality_score()
                    if class_info.quality_metrics
                    else 0
                ),
            }
            metrics_data.append(metrics_dict)
        return metrics_data

    def detect_design_patterns(self, node: ast.ClassDef) -> Set[str]:
        patterns = set()
        if isinstance(node, ast.ClassDef):
            methods = [m.name for m in node.body if isinstance(m, ast.FunctionDef)]
            if any("getInstance" in m for m in methods):
                patterns.add("singleton")
            if any("create" in m.lower() for m in methods):
                patterns.add("factory")
            if any(m in {"notify", "update", "subscribe"} for m in methods):
                patterns.add("observer")
            if node.bases:
                patterns.add("decorator")
            if any("strategy" in m.lower() for m in methods):
                patterns.add("strategy")
        return patterns

    def generate_security_heatmap(self):
        """Generate security issues heatmap"""
        plt.figure(figsize=(15, 10))
        classes = list(self.classes.keys())
        if not classes:
            plt.text(
                0.5,
                0.5,
                "No classes to analyze",
                horizontalalignment="center",
                verticalalignment="center",
            )
            plt.title("Security Issues Heatmap")
            plt.savefig(
                self.export_path / "security_heatmap.png", dpi=300, bbox_inches="tight"
            )
            return
        security_metrics = np.array(
            [
                (
                    [
                        self.classes[cls].security_metrics.critical_issues,
                        self.classes[cls].security_metrics.high_issues,
                        self.classes[cls].security_metrics.medium_issues,
                        self.classes[cls].security_metrics.low_issues,
                    ]
                    if self.classes[cls].security_metrics
                    else [0, 0, 0, 0]
                )
                for cls in classes
            ]
        )
        if security_metrics.size > 0:
            sns.heatmap(
                security_metrics,
                xticklabels=["Critical", "High", "Medium", "Low"],
                yticklabels=classes,
                cmap="YlOrRd",
                annot=True,
                fmt="d",
                cbar_kws={"label": "Number of Issues"},
            )
        plt.title("Security Issues Heatmap")
        plt.tight_layout()
        plt.savefig(
            self.export_path / "security_heatmap.png", dpi=300, bbox_inches="tight"
        )

    def load_html_template(self) -> Template:
        template_string = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Code Analysis Report - {{timestamp}}</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                .section { margin-bottom: 30px; }
                .metric { margin: 10px 0; }
                .visualization { max-width: 100%; margin: 20px 0; }
            </style>
        </head>
        <body>
            <h1>Code Analysis Report</h1>
            <div class="section">
                <h2>Overview</h2>
                <div class="metric">Total Classes: {{total_classes}}</div>
            </div>
            <div class="section">
                <h2>Metrics Summary</h2>
                {% for metric in metrics_summary %}
                <div class="metric">{{metric.name}}: {{metric.value}}</div>
                {% endfor %}
            </div>
            <div class="section">
                <h2>Security Findings</h2>
                {% for finding in security_findings %}
                <div class="metric">{{finding}}</div>
                {% endfor %}
            </div>
            <div class="section">
                <h2>Performance Insights</h2>
                {% for insight in performance_insights %}
                <div class="metric">{{insight}}</div>
                {% endfor %}
            </div>
            <div class="section">
                <h2>Visualizations</h2>
                {% for viz in visualizations %}
                <img src="{{viz}}" class="visualization"/>
                {% endfor %}
            </div>
            <div class="section">
                <h2>Recommendations</h2>
                {% for rec in recommendations %}
                <div class="metric">{{rec}}</div>
                {% endfor %}
            </div>
        </body>
        </html>
        """
        return Template(template_string)

    def generate_metrics_summary(self) -> List[Dict[str, Any]]:
        """Generate a summary of all metrics for reporting"""
        summary = []
        avg_complexity = self._calculate_average_complexity()
        summary.append({"name": "Average Complexity", "value": f"{avg_complexity:.2f}"})
        avg_security = self._calculate_average_security_score()
        summary.append(
            {"name": "Average Security Score", "value": f"{avg_security:.2f}"}
        )
        quality_metrics = {
            "name": "Code Quality",
            "value": f"{self._calculate_average_quality_score():.2f}",
        }
        summary.append(quality_metrics)
        performance_stats = {
            "name": "Performance Score",
            "value": f"{self._calculate_average_performance_score():.2f}",
        }
        summary.append(performance_stats)
        summary.extend(
            [
                {"name": "Total Classes", "value": str(len(self.classes))},
                {"name": "Files Analyzed", "value": str(len(self.metrics_cache))},
                {
                    "name": "Average Methods per Class",
                    "value": f"{self._calculate_average_methods():.2f}",
                },
            ]
        )
        return summary

    def calculate_total_vulnerabilities(self) -> int:
        return sum(
            len(class_info.security_metrics.vulnerabilities)
            for class_info in self.classes.values()
            if class_info.security_metrics
        )

    def calculate_performance_bottlenecks(self) -> int:
        return sum(
            len(class_info.performance_metrics.bottlenecks)
            for class_info in self.classes.values()
            if class_info.performance_metrics
        )

    def _calculate_average_quality_score(self) -> float:
        """Calculate average code quality score"""
        scores = [
            cls.quality_metrics.calculate_quality_score()
            for cls in self.classes.values()
            if cls.quality_metrics
        ]
        return sum(scores) / len(scores) if scores else 0.0

    def _calculate_average_performance_score(self) -> float:
        """Calculate average performance score"""
        scores = [
            cls.performance_metrics.performance_score
            for cls in self.classes.values()
            if hasattr(cls.performance_metrics, "performance_score")
        ]
        return sum(scores) / len(scores) if scores else 0.0

    def _calculate_average_methods(self) -> float:
        """Calculate average number of methods per class"""
        method_counts = [len(cls.methods) for cls in self.classes.values()]
        return sum(method_counts) / len(method_counts) if method_counts else 0.0

    def generate_security_summary(self) -> List[str]:
        """Generate a summary of security findings"""
        security_findings = []
        for class_name, class_info in self.classes.items():
            if class_info.security_metrics:
                if class_info.security_metrics.critical_issues > 0:
                    security_findings.append(
                        f"{class_name}: {class_info.security_metrics.critical_issues} critical security issues"
                    )
                if class_info.security_metrics.high_issues > 0:
                    security_findings.append(
                        f"{class_name}: {class_info.security_metrics.high_issues} high severity issues"
                    )
                if class_info.security_metrics.medium_issues > 0:
                    security_findings.append(
                        f"{class_name}: {class_info.security_metrics.medium_issues} medium severity issues"
                    )
                if class_info.security_vulnerabilities:
                    for vuln in class_info.security_vulnerabilities:
                        security_findings.append(f"{class_name}: {vuln}")
        avg_security = self._calculate_average_security_score()
        security_findings.insert(0, f"Overall Security Score: {avg_security:.2f}")
        return security_findings or ["No security issues found"]

    def generate_performance_summary(self) -> List[str]:
        """Generate a summary of performance insights"""
        performance_insights = []
        for class_name, class_info in self.classes.items():
            if class_info.performance_metrics:
                if class_info.performance_metrics.execution_time > 1.0:
                    performance_insights.append(
                        f"{class_name}: High execution time ({class_info.performance_metrics.execution_time:.2f}s)"
                    )
                if class_info.performance_metrics.memory_usage > 100:
                    performance_insights.append(
                        f"{class_name}: High memory usage ({class_info.performance_metrics.memory_usage:.2f}MB)"
                    )
                if class_info.performance_metrics.cpu_usage > 80:
                    performance_insights.append(
                        f"{class_name}: High CPU usage ({class_info.performance_metrics.cpu_usage:.2f}%)"
                    )
                if class_info.performance_metrics.bottlenecks:
                    for bottleneck in class_info.performance_metrics.bottlenecks:
                        performance_insights.append(
                            f"{class_name}: Performance bottleneck - {bottleneck}"
                        )
        avg_performance = self._calculate_average_performance_score()
        performance_insights.insert(
            0, f"Overall Performance Score: {avg_performance:.2f}"
        )
        return performance_insights or ["No performance issues detected"]

    def add_title_page(self, doc, timestamp: str) -> List:
        """Add a professional title page to the PDF report"""
        elements = []
        title = Paragraph(f"Code Analysis Report", doc.styles["CustomTitle"])
        elements.append(title)
        elements.append(Spacer(1, 30))
        date_text = Paragraph(f"Generated on: {timestamp}", doc.styles["CustomBody"])
        elements.append(date_text)
        elements.append(Spacer(1, 30))
        summary_text = Paragraph(
            f"Total Classes Analyzed: {len(self.classes)}<br/>"
            f"Files Processed: {len(self.metrics_cache)}<br/>"
            f"Analysis Duration: {datetime.datetime.now() - self.analysis_start_time}",
            doc.styles["CustomBody"],
        )
        elements.append(summary_text)
        elements.append(Spacer(1, 60))
        return elements

    def add_executive_summary(self, doc, results: Dict[str, Any]) -> List:
        """Add executive summary section to the PDF report"""
        from reportlab.platypus import Table, TableStyle, Spacer, Paragraph
        from reportlab.lib import colors

        elements = []
        heading = Paragraph("Executive Summary", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        metrics_summary = [
            ["Metric", "Value"],
            ["Total Classes", str(len(results.get("classes", {})))],
            [
                "Average Complexity",
                f"{float(results.get('metrics', {}).get('average_complexity', 0)):.2f}",
            ],
            [
                "Security Score",
                f"{float(results.get('security', {}).get('risk_score', 0)):.2f}",
            ],
            [
                "Quality Score",
                f"{float(results.get('metrics', {}).get('quality_score', 0)):.2f}",
            ],
            [
                "Performance Score",
                f"{float(results.get('performance', {}).get('average_execution_time', 0)):.2f}",
            ],
        ]
        table = Table(metrics_summary, colWidths=[200, 200])
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 14),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 12),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        findings = [
            f"Total Classes Analyzed: {len(results.get('classes', {}))}",
            f"Security Issues Found: {results.get('security', {}).get('total_vulnerabilities', 0)}",
            f"Performance Bottlenecks: {results.get('performance', {}).get('total_bottlenecks', 0)}",
        ]
        findings_para = Paragraph(
            "Key Findings:<br/>"
            + "<br/>".join([f"• {finding}" for finding in findings]),
            doc.styles["CustomBody"],
        )
        elements.append(findings_para)
        return elements

    def add_metrics_section(self, doc, results: Dict[str, Any]) -> List:
        """Add detailed metrics section to the PDF report"""
        from reportlab.lib import colors
        from reportlab.platypus import Table, TableStyle, Spacer, Paragraph

        elements = []
        heading = Paragraph("Detailed Metrics Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        metrics_data = [
            ["Class", "Complexity", "Methods", "Attributes", "Quality Score"]
        ]
        for class_name, class_info in self.classes.items():
            if isinstance(class_info, dict):
                metrics = class_info.get("metrics", {})
                methods = class_info.get("methods", {})
                attributes = class_info.get("attributes", {})
                quality_metrics = class_info.get("quality_metrics", {})
                metrics_data.append(
                    [
                        class_name,
                        str(metrics.get("complexity", 0)),
                        str(len(methods)),
                        str(len(attributes)),
                        (
                            f"{quality_metrics.get('quality_score', 0):.2f}"
                            if quality_metrics
                            else "N/A"
                        ),
                    ]
                )
            else:
                metrics_data.append(
                    [
                        class_name,
                        str(
                            getattr(
                                getattr(class_info, "metrics", None), "complexity", 0
                            )
                        ),
                        str(len(getattr(class_info, "methods", {}))),
                        str(len(getattr(class_info, "attributes", {}))),
                        (
                            f"{class_info.quality_metrics.calculate_quality_score():.2f}"
                            if hasattr(class_info, "quality_metrics")
                            else "N/A"
                        ),
                    ]
                )
        table = Table(metrics_data)
        table._argW = [150, 80, 80, 80, 100]
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 10),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        return elements

    def generate_quality_summary(self) -> List[Dict[str, Any]]:
        """Generate a summary of code quality metrics"""
        quality_metrics = []
        for class_name, class_info in self.classes.items():
            if class_info.quality_metrics:
                metrics = {
                    "class_name": class_name,
                    "maintainability": class_info.quality_metrics.maintainability_index,
                    "test_coverage": class_info.quality_metrics.test_coverage,
                    "documentation": class_info.quality_metrics.documentation_coverage,
                    "code_duplication": class_info.quality_metrics.code_duplication,
                    "naming_violations": class_info.quality_metrics.naming_convention_violations,
                    "style_violations": class_info.quality_metrics.style_violations,
                    "type_safety": class_info.quality_metrics.type_safety_score,
                }
                quality_score = class_info.quality_metrics.calculate_quality_score()
                metrics["overall_score"] = quality_score
                quality_metrics.append(metrics)
        if quality_metrics:
            avg_quality = sum(m["overall_score"] for m in quality_metrics) / len(
                quality_metrics
            )
            quality_metrics.insert(
                0,
                {
                    "class_name": "Overall",
                    "overall_score": avg_quality,
                    "total_classes": len(quality_metrics),
                },
            )
        return quality_metrics or [
            {"class_name": "Overall", "message": "No quality metrics available"}
        ]

    def get_visualization_paths(self) -> List[str]:
        """Get paths to all generated visualization files"""
        visualization_files = [
            "class_hierarchy.png",
            "dependency_network.png",
            "metrics_dashboard.png",
            "security_heatmap.png",
        ]
        return [
            str(self.export_path / viz_file)
            for viz_file in visualization_files
            if (self.export_path / viz_file).exists()
        ]

    def generate_recommendations(self) -> List[str]:
        """Generate improvement recommendations based on analysis results"""
        recommendations = []
        for class_name, class_info in self.classes.items():
            if class_info.metrics.complexity > 30:
                recommendations.append(
                    f"{class_name}: Consider breaking down complex methods to improve maintainability"
                )
            if (
                class_info.security_metrics
                and class_info.security_metrics.security_score < 80
            ):
                recommendations.append(
                    f"{class_name}: Address security vulnerabilities to improve security score"
                )
            if class_info.performance_metrics:
                if class_info.performance_metrics.memory_usage > 100:
                    recommendations.append(
                        f"{class_name}: Optimize memory usage through better resource management"
                    )
                if class_info.performance_metrics.execution_time > 1.0:
                    recommendations.append(
                        f"{class_name}: Consider performance optimization for slow methods"
                    )
            if class_info.quality_metrics:
                if class_info.quality_metrics.test_coverage < 80:
                    recommendations.append(
                        f"{class_name}: Increase test coverage to improve code reliability"
                    )
                if class_info.quality_metrics.documentation_coverage < 70:
                    recommendations.append(
                        f"{class_name}: Improve documentation coverage for better maintainability"
                    )
            if class_info.code_smells:
                recommendations.append(
                    f"{class_name}: Consider refactoring to address code smells: {', '.join(class_info.code_smells)}"
                )
        return recommendations or ["No specific recommendations at this time"]

    def initialize_pdf_document(self) -> SimpleDocTemplate:
        """Initialize PDF document with basic styling"""
        pdf_path = str(
            self.export_path
            / f"analysis_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
        )
        doc = SimpleDocTemplate(
            pdf_path,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72,
        )
        styles = getSampleStyleSheet()
        styles.add(
            ParagraphStyle(
                name="CustomTitle",
                fontSize=24,
                spaceAfter=30,
                alignment=1,  # Center alignment
            )
        )
        styles.add(
            ParagraphStyle(
                name="CustomHeading", fontSize=18, spaceAfter=12, spaceBefore=24
            )
        )
        styles.add(ParagraphStyle(name="CustomBody", fontSize=12, spaceAfter=6))
        doc.styles = styles
        return doc

    def export_advanced_results(self):
        """Export analysis results in multiple formats"""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        def convert_to_serializable(obj):
            if hasattr(obj, "__dict__"):
                return {
                    k: list(v) if isinstance(v, set) else v
                    for k, v in obj.__dict__.items()
                }
            return str(obj)

        results = {
            "classes": {
                name: convert_to_serializable(info)
                for name, info in self.classes.items()
            },
            "metrics": self.metrics_cache,
            "security": {
                "total_vulnerabilities": sum(
                    len(getattr(c, "security_vulnerabilities", []) or [])
                    for c in self.classes.values()
                ),
                "risk_score": (
                    sum(
                        getattr(
                            getattr(c, "security_metrics", None), "security_score", 0
                        )
                        for c in self.classes.values()
                    )
                    / len(self.classes)
                    if self.classes
                    else 0
                ),
            },
            "performance": {
                "total_bottlenecks": sum(
                    len(getattr(c, "performance_bottlenecks", []) or [])
                    for c in self.classes.values()
                ),
                "average_execution_time": (
                    sum(
                        getattr(
                            getattr(c, "performance_metrics", None), "execution_time", 0
                        )
                        for c in self.classes.values()
                    )
                    / len(self.classes)
                    if self.classes
                    else 0
                ),
            },
        }
        self.console.print("\n[bold cyan]📊 Generating Analysis Reports:[/bold cyan]")
        pdf_path = self.export_path / f"analysis_report_{timestamp}.pdf"
        self.generate_pdf_report(results, timestamp)
        self.console.print(f"[green]✓[/green] PDF Report: {pdf_path}")
        html_path = self.export_path / f"interactive_report_{timestamp}.html"
        self.generate_interactive_html_report(results, timestamp)
        self.console.print(f"[green]✓[/green] HTML Report: {html_path}")
        json_path = self.export_path / f"raw_results_{timestamp}.json"
        with open(json_path, "w") as f:
            json.dump(results, f, indent=4, default=convert_to_serializable)
        self.console.print(f"[green]✓[/green] JSON Results: {json_path}")
        self.console.print("\n[bold cyan]📈Extra Analysis Summary:[/bold cyan]")
        self.console.print(
            f"[yellow]Performance score:[/yellow] {results['performance']['average_execution_time']:.2f}"
        )

    def _generate_key_findings(self) -> List[str]:
        """Generate key findings for the executive summary"""
        findings = []
        if any(cls.metrics.complexity > 30 for cls in self.classes.values()):
            findings.append("High complexity detected in some classes")
        if any(
            cls.security_metrics and cls.security_metrics.critical_issues > 0
            for cls in self.classes.values()
        ):
            findings.append("Critical security issues found")
        if any(
            cls.performance_metrics and cls.performance_metrics.bottlenecks
            for cls in self.classes.values()
        ):
            findings.append("Performance bottlenecks identified")
        low_quality_classes = [
            cls
            for cls in self.classes.values()
            if cls.quality_metrics
            and cls.quality_metrics.calculate_quality_score() < 70
        ]
        if low_quality_classes:
            findings.append(
                f"{len(low_quality_classes)} classes need quality improvements"
            )
        return findings or ["No significant issues found"]

    def add_quality_section(self, doc, results: Dict[str, Any]) -> List:
        """Add code quality analysis section to the PDF report"""
        from reportlab.platypus import Table, TableStyle

        elements = []
        heading = Paragraph("Code Quality Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        quality_data = [
            [
                "Class",
                "Maintainability",
                "Test Coverage",
                "Documentation",
                "Style Score",
            ]
        ]
        for class_name, class_info in self.classes.items():
            if class_info.quality_metrics:
                quality_data.append(
                    [
                        class_name,
                        f"{class_info.quality_metrics.maintainability_index:.2f}",
                        f"{class_info.quality_metrics.test_coverage:.2f}%",
                        f"{class_info.quality_metrics.documentation_coverage:.2f}%",
                        f"{class_info.quality_metrics.calculate_quality_score():.2f}",
                    ]
                )
        table = Table(quality_data)
        table._argW = [150, 100, 100, 100, 100]  # Set column widths directly
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 10),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        for class_name, class_info in self.classes.items():
            if class_info.code_smells or class_info.refactoring_suggestions:
                quality_issues = Paragraph(
                    f"<b>{class_name} Quality Issues:</b><br/>"
                    + (
                        "<br/>".join(
                            [
                                f"• Code Smell: {smell}"
                                for smell in class_info.code_smells
                            ]
                        )
                        if class_info.code_smells
                        else ""
                    )
                    + (
                        "<br/>"
                        if class_info.code_smells and class_info.refactoring_suggestions
                        else ""
                    )
                    + (
                        "<br/>".join(
                            [
                                f"• Suggestion: {suggestion}"
                                for suggestion in class_info.refactoring_suggestions
                            ]
                        )
                        if class_info.refactoring_suggestions
                        else ""
                    ),
                    doc.styles["CustomBody"],
                )
                elements.append(quality_issues)
                elements.append(Spacer(1, 10))
        return elements

    def add_performance_section(self, doc, results: Dict[str, Any]) -> List:
        """Add performance analysis section to the PDF report"""
        from reportlab.platypus import Table, TableStyle

        elements = []
        heading = Paragraph("Performance Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        perf_data = [["Class", "Execution Time", "Memory Usage", "CPU Usage", "Score"]]
        for class_name, class_info in self.classes.items():
            if class_info.performance_metrics:
                perf_data.append(
                    [
                        class_name,
                        f"{class_info.performance_metrics.execution_time:.2f}s",
                        f"{class_info.performance_metrics.memory_usage:.2f}MB",
                        f"{class_info.performance_metrics.cpu_usage:.2f}%",
                        str(
                            getattr(
                                class_info.performance_metrics,
                                "performance_score",
                                "N/A",
                            )
                        ),
                    ]
                )
        table = Table(perf_data)
        table._argW = [150, 100, 100, 100, 70]  # Direct width setting
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 10),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        for class_name, class_info in self.classes.items():
            if (
                class_info.performance_metrics
                and class_info.performance_metrics.bottlenecks
            ):
                bottlenecks = Paragraph(
                    f"<b>{class_name} Performance Bottlenecks:</b><br/>"
                    + "<br/>".join(
                        [
                            f"• {bottleneck}"
                            for bottleneck in class_info.performance_metrics.bottlenecks
                        ]
                    ),
                    doc.styles["CustomBody"],
                )
                elements.append(bottlenecks)
                elements.append(Spacer(1, 10))
        return elements

    def add_quality_section(self, doc, results: Dict[str, Any]) -> List:
        elements = []
        heading = Paragraph("Code Quality Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        quality_data = [
            [
                "Class",
                "Maintainability",
                "Test Coverage",
                "Documentation",
                "Style Score",
            ]
        ]
        for class_name, class_info in self.classes.items():
            if hasattr(class_info, "quality_metrics") and class_info.quality_metrics:
                maintainability = float(mi_visit(str(class_info), multi=True))
                test_coverage = (
                    len(class_info.methods) > 0
                    and sum(1 for m in class_info.methods if "test" in m.lower())
                    / len(class_info.methods)
                    * 100
                )
                doc_coverage = (
                    sum(
                        1
                        for m in class_info.methods.values()
                        if isinstance(m, dict) and m.get("docstring")
                    )
                    / len(class_info.methods)
                    * 100
                    if class_info.methods
                    else 0
                )
                style_score = 100 - (len(class_info.code_smells) * 5)
                quality_data.append(
                    [
                        class_name,
                        f"{maintainability:.2f}",
                        f"{test_coverage:.2f}%",
                        f"{doc_coverage:.2f}%",
                        f"{style_score:.2f}",
                    ]
                )
        table = Table(quality_data, colWidths=[150, 100, 100, 100, 100])
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 10),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        for class_name, class_info in self.classes.items():
            if class_info.code_smells or hasattr(class_info, "refactoring_suggestions"):
                issues_text = []
                if class_info.code_smells:
                    issues_text.extend(
                        [f"• Code Smell: {smell}" for smell in class_info.code_smells]
                    )
                if (
                    hasattr(class_info, "refactoring_suggestions")
                    and class_info.refactoring_suggestions
                ):
                    issues_text.extend(
                        [
                            f"• Suggestion: {sugg}"
                            for sugg in class_info.refactoring_suggestions
                        ]
                    )
                if issues_text:
                    quality_issues = Paragraph(
                        f"<b>{class_name} Quality Issues:</b><br/>"
                        + "<br/>".join(issues_text),
                        doc.styles["CustomBody"],
                    )
                    elements.append(quality_issues)
                    elements.append(Spacer(1, 10))
        return elements

    def add_visualization_pages(self, doc) -> List:
        """Add visualization pages to the PDF report"""
        elements = []
        heading = Paragraph("Visual Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        viz_paths = self.get_visualization_paths()
        for viz_path in viz_paths:
            viz_name = Path(viz_path).stem.replace("_", " ").title()
            title = Paragraph(viz_name, doc.styles["CustomBody"])
            elements.append(title)
            elements.append(Spacer(1, 10))
            img = Image(viz_path, width=500, height=300)
            elements.append(img)
            elements.append(Spacer(1, 30))
        return elements

    def add_recommendations_section(self, doc, results: Dict[str, Any]) -> List:
        """Add recommendations section to the PDF report"""
        elements = []
        heading = Paragraph(
            "Recommendations and Next Steps", doc.styles["CustomHeading"]
        )
        elements.append(heading)
        elements.append(Spacer(1, 20))
        recommendations = {
            "High Priority": [],
            "Medium Priority": [],
            "Low Priority": [],
        }
        for class_name, class_info in self.classes.items():
            if (
                class_info.security_metrics
                and class_info.security_metrics.critical_issues > 0
            ):
                recommendations["High Priority"].append(
                    f"Address critical security issues in {class_name}"
                )
            if (
                class_info.performance_metrics
                and class_info.performance_metrics.execution_time > 1.0
            ):
                recommendations["Medium Priority"].append(
                    f"Optimize performance bottlenecks in {class_name}"
                )
            if (
                class_info.quality_metrics
                and class_info.quality_metrics.test_coverage < 80
            ):
                recommendations["Medium Priority"].append(
                    f"Increase test coverage for {class_name}"
                )
            if class_info.code_smells:
                recommendations["Low Priority"].append(
                    f"Address code smells in {class_name}: {', '.join(class_info.code_smells)}"
                )
        for priority, recs in recommendations.items():
            if recs:
                priority_heading = Paragraph(
                    f"<b>{priority}</b>", doc.styles["CustomBody"]
                )
                elements.append(priority_heading)
                elements.append(Spacer(1, 10))
                for rec in recs:
                    rec_text = Paragraph(f"• {rec}", doc.styles["CustomBody"])
                    elements.append(rec_text)
                elements.append(Spacer(1, 20))
        return elements

    def calculate_dependency_weight(self, source: str, target: str) -> float:
        """Calculate dependency weight between two classes"""
        source_class = self.classes.get(source)
        target_class = self.classes.get(target)
        if not source_class or not target_class:
            return 0.0
        weight = 0.0
        weight += len(
            [
                m
                for m in source_class.methods.values()
                if isinstance(m, dict)
                and any(call in target_class.methods for call in m.get("calls", []))
            ]
        )
        weight += len(set(source_class.attributes).intersection(target_class.methods))
        return weight

    def generate_performance_charts(self):
        """Generate performance analysis charts"""
        plt.figure(figsize=(15, 10))
        classes = list(self.classes.keys())
        execution_times = []
        memory_usage = []
        for cls in classes:
            perf_metrics = self.classes[cls].performance_metrics
            execution_times.append(perf_metrics.execution_time if perf_metrics else 0)
            memory_usage.append(perf_metrics.memory_usage if perf_metrics else 0)
        plt.subplot(2, 1, 1)
        plt.bar(classes, execution_times, color="skyblue")
        plt.title("Execution Time by Class")
        plt.xticks(rotation=45)
        plt.subplot(2, 1, 2)
        plt.bar(classes, memory_usage, color="lightgreen")
        plt.title("Memory Usage by Class")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(
            self.export_path / "performance_charts.png", dpi=300, bbox_inches="tight"
        )

    from rich.table import Table

    def display_analysis_summary(self):
        """Display summary of analysis results"""
        from rich.table import Table

        total_vulnerabilities = sum(
            (
                len(class_info.security_metrics.vulnerabilities)
                if class_info.security_metrics
                else 0
            )
            for class_info in self.classes.values()
        )
        performance_bottlenecks = sum(
            (
                len(class_info.performance_metrics.bottlenecks)
                if class_info.performance_metrics
                else 0
            )
            for class_info in self.classes.values()
        )
        quality_scores = [
            class_info.quality_metrics.calculate_quality_score()
            for class_info in self.classes.values()
            if class_info.quality_metrics
        ]
        average_quality = (
            sum(quality_scores) / len(quality_scores) if quality_scores else 0
        )
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="magenta")
        table.add_row("Total Classes", str(len(self.classes)))
        table.add_row("Files Analyzed", str(len(self.metrics_cache)))
        table.add_row(
            "Average Complexity", f"{self._calculate_average_complexity():.2f}"
        )
        table.add_row(
            "Security Score", f"{self._calculate_average_security_score():.2f}"
        )
        table.add_row("Quality Score", f"{average_quality:.2f}")
        table.add_row("Total Vulnerabilities", str(total_vulnerabilities))
        table.add_row("Performance Bottlenecks", str(performance_bottlenecks))
        self.console.print("\n[bold cyan]Analysis Summary[/bold cyan]\n")
        self.console.print(table)

    def _calculate_average_complexity(self) -> float:
        """Calculate average complexity across all classes"""
        complexities = [cls.metrics.complexity for cls in self.classes.values()]
        return sum(complexities) / len(complexities) if complexities else 0.0

    def _calculate_average_security_score(self) -> float:
        """Calculate average security score across all classes"""
        scores = [
            cls.security_metrics.security_score
            for cls in self.classes.values()
            if cls.security_metrics
        ]
        return sum(scores) / len(scores) if scores else 0.0

    def load_pattern_database(self) -> Dict[str, Dict[str, Any]]:
        return {
            "design_patterns": {
                "singleton": {
                    "indicators": ["getInstance", "private constructor"],
                    "weight": 0.8,
                },
                "factory": {
                    "indicators": ["createInstance", "factory method"],
                    "weight": 0.7,
                },
                "observer": {
                    "indicators": ["notify", "subscribe", "observer"],
                    "weight": 0.6,
                },
            },
            "anti_patterns": {
                "god_class": {
                    "indicators": ["large class", "high complexity"],
                    "weight": 0.9,
                },
                "spaghetti_code": {
                    "indicators": ["goto", "complex flow"],
                    "weight": 0.8,
                },
            },
        }

    def analyze_file_content(self, file_path: str, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = {
                executor.submit(self.analyze_classes, content): "classes",
                executor.submit(self.analyze_security, content): "security",
                executor.submit(self.analyze_performance, content): "performance",
                executor.submit(self.analyze_quality, content): "quality",
            }
            for future in concurrent.futures.as_completed(futures):
                key = futures[future]
                try:
                    analysis_results[key] = future.result()
                except Exception as e:
                    logging.error(f"Error in {key} analysis: {str(e)}")
                    analysis_results[key] = {"error": str(e)}
        return analysis_results

    def analyze_classes(self, content: str) -> Dict[str, EnhancedClassInfo]:
        classes = {}
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, ast.ClassDef):
                    class_info = self.extract_class_info(node, content)
                    classes[class_info.name] = class_info
        except Exception as e:
            logging.error(f"Error in class analysis: {e}")
        return classes

    def extract_class_info(self, node: ast.ClassDef, content: str) -> EnhancedClassInfo:
        class_info = EnhancedClassInfo(
            name=node.name, file_type="Python", file_path=str(node.lineno)
        )
        for item in node.body:
            if isinstance(item, ast.FunctionDef):
                class_info.methods[item.name] = self.analyze_method(item)
        for item in node.body:
            if isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        class_info.attributes[target.id] = self.analyze_attribute(item)
        class_info.metrics = self.calculate_advanced_metrics(node, content)
        class_info.design_patterns = self.detect_design_patterns(node)
        class_info.security_metrics = self.analyze_security_node(node)
        class_info.performance_metrics = self.analyze_performance_node(node)
        return class_info

    def analyze_method(self, node: ast.FunctionDef) -> Dict[str, Any]:
        return {
            "args": [arg.arg for arg in node.args.args],
            "decorators": [
                d.id for d in node.decorator_list if isinstance(d, ast.Name)
            ],
            "complexity": self.calculate_method_complexity(node),
            "lines": len(node.body),
            "returns": self.analyze_return_types(node),
            "calls": self.analyze_method_calls(node),
            "security_issues": self.check_method_security(node),
        }

    def calculate_method_complexity(self, node: ast.FunctionDef) -> int:
        complexity = 1  # Base complexity
        for child in ast.walk(node):
            if isinstance(
                child, (ast.If, ast.While, ast.For, ast.Try, ast.ExceptHandler)
            ):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        return complexity

    def setup_advanced_logging(self):
        log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        logging.basicConfig(
            level=logging.INFO,
            format=log_format,
            handlers=[
                logging.FileHandler(self.export_path / "analysis.log"),
                logging.StreamHandler(),
            ],
        )

    logging.info("Advanced logging initialized")

    def analyze_performance_node(self, node: ast.ClassDef) -> PerformanceMetrics:
        performance_metrics = PerformanceMetrics()
        try:
            cProfile.Profile().disable()
            for method in node.body:
                if isinstance(method, ast.FunctionDef):
                    stats = {"loops": 0, "nested_loops": 0, "io_operations": 0}
                    for child in ast.walk(method):
                        if isinstance(child, (ast.For, ast.While)):
                            stats["loops"] += 1
                            for nested in ast.walk(child):
                                if isinstance(nested, (ast.For, ast.While)):
                                    stats["nested_loops"] += 1
                        if isinstance(child, ast.Call) and isinstance(
                            child.func, ast.Name
                        ):
                            if child.func.id in ["open", "read", "write"]:
                                stats["io_operations"] += 1
                    if stats["nested_loops"] > 0:
                        performance_metrics.bottlenecks.append(
                            f"Nested loops in method {method.name}"
                        )
                    performance_metrics.io_operations += stats["io_operations"]
            performance_metrics.execution_time = (
                sum(
                    len(list(ast.walk(m)))
                    for m in node.body
                    if isinstance(m, ast.FunctionDef)
                )
                * 0.01
            )
            performance_metrics.memory_usage = len(list(ast.walk(node))) * 0.1
            performance_metrics.calculate_performance_score()
        except Exception as e:
            logging.error(f"Performance node analysis error: {str(e)}")
        return performance_metrics

    def analyze_security_node(self, node: ast.ClassDef) -> SecurityMetrics:
        security_metrics = SecurityMetrics()
        try:
            for method in node.body:
                if isinstance(method, ast.FunctionDef):
                    for child in ast.walk(method):
                        if isinstance(child, ast.Call):
                            if isinstance(child.func, ast.Name):
                                if child.func.id in ["eval", "exec", "input"]:
                                    security_metrics.vulnerabilities.append(
                                        {
                                            "severity": "HIGH",
                                            "type": "dangerous_function",
                                            "location": f"method {method.name}",
                                        }
                                    )
                        if isinstance(child, ast.Assign):
                            if isinstance(child.value, ast.Constant):
                                if any(
                                    word in str(child.value.value).lower()
                                    for word in ["password", "secret", "key"]
                                ):
                                    security_metrics.vulnerabilities.append(
                                        {
                                            "severity": "MEDIUM",
                                            "type": "hardcoded_credentials",
                                            "location": f"method {method.name}",
                                        }
                                    )
            security_metrics.calculate_security_metrics()
        except Exception as e:
            logging.error(f"Security node analysis error: {str(e)}")
        return security_metrics

    def analyze_security(self, content: str) -> Dict[str, Any]:
        """Enhanced security analysis with proper Bandit integration"""
        security_results = {
            "vulnerabilities": [],
            "risk_score": 100,
            "security_issues": [],
        }
        try:
            content_encoded = content.encode("utf-8").decode("utf-8")
            bandit_config = BanditConfig()
            scanner = BanditManager(bandit_config, "file")
            scanner.discover_files([content_encoded])
            issues = scanner.run_tests()
            for issue in issues:
                security_results["vulnerabilities"].append(
                    {
                        "severity": issue.severity,
                        "confidence": issue.confidence,
                        "description": issue.description,
                        "line_number": issue.lineno,
                        "code": issue.code,
                    }
                )
                if issue.severity == "HIGH":
                    security_results["risk_score"] -= 10
                elif issue.severity == "MEDIUM":
                    security_results["risk_score"] -= 5
                elif issue.severity == "LOW":
                    security_results["risk_score"] -= 2
        except Exception as e:
            logging.error(f"Security analysis error: {str(e)}")
        return security_results

    def analyze_performance(self, content: str) -> Dict[str, Any]:
        self.profiler = cProfile.Profile()
        performance_results = {
            "execution_time": 0.0,
            "memory_usage": 0.0,
            "bottlenecks": [],
            "cpu_usage": 0.0,
            "memory_peaks": [],
        }
        try:
            initial_memory = memory_profiler.memory_usage()[0]
            start_time = datetime.datetime.now()
            self.profiler.enable()
            local_vars = {}
            exec(compile(content, "<string>", "exec"), {}, local_vars)
            self.profiler.disable()
            end_time = datetime.datetime.now()
            performance_results["execution_time"] = (
                end_time - start_time
            ).total_seconds()
            current_memory = memory_profiler.memory_usage()[0]
            performance_results["memory_usage"] = current_memory - initial_memory
            stats = pstats.Stats(self.profiler)
            stats.sort_stats("cumulative")
            for func_name, stats_data in stats.stats.items():
                if stats_data[3] > 0.1:  # Time threshold
                    performance_results["bottlenecks"].append(
                        {
                            "function": str(func_name),
                            "time": stats_data[3],
                            "calls": stats_data[0],
                            "time_per_call": (
                                stats_data[3] / stats_data[0]
                                if stats_data[0] > 0
                                else 0
                            ),
                            "percentage": (
                                (stats_data[3] / performance_results["execution_time"])
                                * 100
                                if performance_results["execution_time"] > 0
                                else 0
                            ),
                        }
                    )
            performance_results["bottlenecks"].sort(
                key=lambda x: x["time"], reverse=True
            )
        except Exception as e:
            logging.error(f"Performance analysis error: {str(e)}")
        return performance_results

    def analyze_java_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        try:
            tree = javalang.parse.parse(content)
            for path, node in tree.filter(javalang.tree.ClassDeclaration):
                class_info = EnhancedClassInfo(
                    name=node.name, file_type="Java", file_path=str(path)
                )
                for method in node.methods:
                    class_info.methods[method.name] = {
                        "args": [param.name for param in method.parameters],
                        "modifiers": method.modifiers,
                        "returns": (
                            str(method.return_type) if method.return_type else "void"
                        ),
                    }
                for field in node.fields:
                    class_info.attributes[field.declarators[0].name] = str(field.type)
                analysis_results["classes"][node.name] = class_info
        except Exception as e:
            logging.error(f"Java analysis error: {str(e)}")
            return analysis_results

    def analyze_javascript_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        try:
            tree = esprima.parseScript(content, {"loc": True, "range": True})
            for node in tree.body:
                if node.type in ["ClassDeclaration", "ClassExpression"]:
                    class_info = EnhancedClassInfo(
                        name=node.id.name if hasattr(node, "id") else "AnonymousClass",
                        file_type="JavaScript",
                        file_path=str(node.loc.start.line),
                    )
                for element in node.body.body:
                    if element.type == "MethodDefinition":
                        class_info.methods[element.key.name] = {
                            "kind": element.kind,
                            "static": element.static,
                            "computed": element.computed,
                        }
                    elif element.type == "PropertyDefinition":
                        class_info.attributes[element.key.name] = "property"
                analysis_results["classes"][class_info.name] = class_info
        except Exception as e:
            logging.error(f"JavaScript analysis error: {str(e)}")
        return analysis_results

    def analyze_cpp_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        try:
            class_pattern = r"class\s+(\w+)(?:\s*:\s*(?:public|private|protected)\s+(\w+))?\s*\{([\s\S]*?)\};"
            method_pattern = r"(?:public|private|protected):\s*(?:virtual\s+)?(\w+)\s+(\w+)\s*\([^)]*\)"
            property_pattern = r"(?:public|private|protected):\s*(\w+)\s+(\w+);"
            template_pattern = r"template\s*<[^>]+>\s*class\s+(\w+)"
            for match in re.finditer(class_pattern, content):
                class_name = match.group(1)
                parent_class = match.group(2)
                class_body = match.group(3)
                class_info = EnhancedClassInfo(
                    name=class_name, file_type="C++", file_path="cpp_file"
                )
                if parent_class:
                    class_info.parent_classes.add(parent_class)
                visibility = "private"
                for method_match in re.finditer(method_pattern, class_body):
                    return_type, method_name = method_match.groups()
                    if "public:" in class_body[: method_match.start()]:
                        visibility = "public"
                    elif "private:" in class_body[: method_match.start()]:
                        visibility = "private"
                    elif "protected:" in class_body[: method_match.start()]:
                        visibility = "protected"
                    class_info.methods[method_name] = {
                        "return_type": return_type,
                        "visibility": visibility,
                        "virtual": bool(re.search(r"virtual", method_match.group(0))),
                        "const": bool(re.search(r"const$", method_match.group(0))),
                    }
                for prop_match in re.finditer(property_pattern, class_body):
                    type_name, prop_name = prop_match.groups()
                    class_info.attributes[prop_name] = {
                        "type": type_name,
                        "visibility": visibility,
                    }
                class_info.metrics = AdvancedMetrics()
                class_info.metrics.complexity = len(
                    re.findall(r"\b(if|while|for|switch)\b", class_body)
                ) + len(re.findall(r"&&|\|\|", class_body))
                class_info.metrics.lines_of_code = len(class_body.splitlines())
                class_info.metrics.method_count = len(class_info.methods)
                class_info.metrics.attribute_count = len(class_info.attributes)
                class_info.performance_metrics = PerformanceMetrics()
                class_info.performance_metrics.bottlenecks = [
                    {"type": "memory_leak", "location": loc}
                    for loc in re.finditer(r"new\s+\w+", class_body)
                    if not re.search(r"delete", class_body[loc.end() :])
                ]
                analysis_results["classes"][class_name] = class_info
        except Exception as e:
            logging.error(f"C++ analysis error: {str(e)}")
        return analysis_results

    def analyze_csharp_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        try:
            class_pattern = (
                r"(?:public|private|internal)?\s*class\s+(\w+)(?:\s*:\s*\w+)?\s*\{"
            )
            method_pattern = r"(?:public|private|protected|internal)\s+(?:virtual\s+)?(\w+)\s+(\w+)\s*\([^)]*\)"
            property_pattern = (
                r"(?:public|private|protected|internal)\s+(\w+)\s+(\w+)\s*\{[^}]*\}"
            )
            for match in re.finditer(class_pattern, content):
                class_name = match.group(1)
                class_info = EnhancedClassInfo(
                    name=class_name, file_type="C#", file_path="cs_file"
                )
                class_content = content[match.start() :]
                for method_match in re.finditer(method_pattern, class_content):
                    return_type, method_name = method_match.groups()
                    class_info.methods[method_name] = {"return_type": return_type}
                for prop_match in re.finditer(property_pattern, class_content):
                    type_name, prop_name = prop_match.groups()
                    class_info.properties.add(prop_name)
                analysis_results["classes"][class_name] = class_info
        except Exception as e:
            logging.error(f"C# analysis error: {str(e)}")
        return analysis_results

    def analyze_typescript_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        try:
            tree = esprima.parseModule(content, {"loc": True, "range": True})
            for node in tree.body:
                if node.type == "ClassDeclaration":
                    class_info = EnhancedClassInfo(
                        name=node.id.name,
                        file_type="TypeScript",
                        file_path=str(node.loc.start.line),
                    )
                    if hasattr(node, "superClass") and node.superClass:
                        class_info.parent_classes.add(node.superClass.name)
                    for element in node.body.body:
                        if element.type == "MethodDefinition":
                            is_async = False
                            if hasattr(element.value, "async"):
                                is_async = element.value.async_
                            class_info.methods[element.key.name] = {
                                "kind": element.kind,
                                "static": element.static,
                                "type_parameters": self.extract_ts_type_parameters(
                                    element
                                ),
                                "return_type": self.extract_ts_type_annotation(element),
                                "complexity": len(list(ast.walk(element.value))),
                                "is_async": is_async,
                            }
                        elif element.type == "PropertyDefinition":
                            class_info.attributes[element.key.name] = {
                                "type": self.extract_ts_type_annotation(element),
                                "visibility": (
                                    "private"
                                    if element.key.name.startswith("_")
                                    else "public"
                                ),
                                "static": (
                                    element.static
                                    if hasattr(element, "static")
                                    else False
                                ),
                            }
                    class_info.metrics = AdvancedMetrics()
                    class_info.metrics.complexity = sum(
                        method.get("complexity", 0)
                        for method in class_info.methods.values()
                    )
                    class_info.metrics.method_count = len(class_info.methods)
                    class_info.metrics.attribute_count = len(class_info.attributes)
                    class_info.security_metrics = SecurityMetrics()
                    class_info.performance_metrics = PerformanceMetrics()
                    analysis_results["classes"][class_info.name] = class_info
        except Exception as e:
            logging.error(f"TypeScript analysis error: {str(e)}")
        return analysis_results

    def extract_ts_type_parameters(self, node) -> List[str]:
        """Extract TypeScript type parameters"""
        type_params = []
        if hasattr(node, "typeParameters"):
            for param in node.typeParameters:
                type_params.append(param.name)
        return type_params

    def extract_ts_type_annotation(self, node) -> str:
        """Extract TypeScript type annotations"""
        if hasattr(node, "typeAnnotation"):
            return node.typeAnnotation.type
        return "any"

    def analyze_quality(self, content: str) -> Dict[str, Any]:
        quality_results = {
            "maintainability": 0.0,
            "complexity": 0.0,
            "code_smells": [],
            "documentation_score": 0.0,
            "test_coverage": 0.0,
            "style_score": 0.0,
        }
        try:
            quality_results["maintainability"] = mi_visit(content, multi=True)
            quality_results["complexity"] = sum(
                cc.complexity for cc in cc_visit(content)
            )
            tree = ast.parse(content)
            doc_count = sum(
                1
                for node in ast.walk(tree)
                if isinstance(node, (ast.FunctionDef, ast.ClassDef))
                and ast.get_docstring(node)
            )
            total_nodes = sum(
                1
                for node in ast.walk(tree)
                if isinstance(node, (ast.FunctionDef, ast.ClassDef))
            )
            quality_results["documentation_score"] = (
                (doc_count / total_nodes * 100) if total_nodes > 0 else 0
            )
            vulture = Vulture()
            vulture.scan(content)
            quality_results["code_smells"].extend(
                [{"type": "unused_code", "item": item} for item in vulture.unused_funcs]
            )
            style_violations = len(re.findall(r"[A-Z]{2,}|[a-z]+_[a-z]+", content))
            quality_results["style_score"] = max(0, 100 - style_violations)
            quality_results["overall_score"] = (
                quality_results["maintainability"] * 0.3
                + (100 - quality_results["complexity"]) * 0.3
                + quality_results["documentation_score"] * 0.2
                + quality_results["style_score"] * 0.2
            )
        except Exception as e:
            logging.error(f"Quality analysis error: {str(e)}")
        return quality_results

    def calculate_advanced_metrics(
        self, node: ast.ClassDef, content: str
    ) -> AdvancedMetrics:
        metrics = AdvancedMetrics()
        try:
            metrics.lines_of_code = len(
                [line for line in content.splitlines() if line.strip()]
            )
            metrics.method_count = sum(
                1 for n in ast.walk(node) if isinstance(n, ast.FunctionDef)
            )
            metrics.attribute_count = sum(
                1 for n in ast.walk(node) if isinstance(n, ast.Assign)
            )
            control_structures = (
                ast.If,
                ast.While,
                ast.For,
                ast.Try,
                ast.With,
                ast.AsyncWith,
                ast.ExceptHandler,
            )
            metrics.cyclomatic_complexity = 1 + sum(
                1 for _ in ast.walk(node) if isinstance(_, control_structures)
            )
            nesting_level = 0
            cognitive_score = 0
            for child in ast.walk(node):
                if isinstance(child, (ast.If, ast.While, ast.For)):
                    cognitive_score += 1 + nesting_level
                    nesting_level += 1
                elif isinstance(child, ast.BoolOp):
                    cognitive_score += len(child.values) - 1
            metrics.cognitive_complexity = cognitive_score
            metrics.fan_in = sum(1 for _ in ast.walk(node) if isinstance(_, ast.Name))
            metrics.fan_out = sum(1 for _ in ast.walk(node) if isinstance(_, ast.Call))
            base_complexity = (
                metrics.cyclomatic_complexity * 0.35
                + metrics.cognitive_complexity * 0.35
                + metrics.fan_in * 0.15
                + metrics.fan_out * 0.15
            )
            metrics.complexity = min(100, max(1, base_complexity * 5))
        except Exception as e:
            logging.error(f"Metrics calculation error: {str(e)}")
            metrics.complexity = 10  # Default complexity for error cases
        return metrics

    def calculate_cognitive_complexity(self, node: ast.AST) -> int:
        complexity = 0
        nesting = 0
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For)):
                complexity += 1 + nesting
                nesting += 1
            elif isinstance(child, ast.FunctionDef):
                complexity += self.calculate_cognitive_complexity(child)
        return complexity

    def analyze_attribute(self, node: ast.Assign) -> str:
        try:
            return (
                ast.unparse(node.value)
                if hasattr(ast, "unparse")
                else ast.dump(node.value)
            )
        except Exception:
            return str(node.value)

    def analyze_return_types(self, node: ast.FunctionDef) -> List[str]:
        return_types = []
        for child in ast.walk(node):
            if isinstance(child, ast.Return) and child.value:
                if isinstance(child.value, ast.Name):
                    return_types.append(child.value.id)
                elif isinstance(child.value, ast.Constant):
                    return_types.append(type(child.value.value).__name__)
        return return_types

    def analyze_method_calls(self, node: ast.FunctionDef) -> List[str]:
        calls = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                if isinstance(child.func, ast.Name):
                    calls.append(child.func.id)
                elif isinstance(child.func, ast.Attribute):
                    calls.append(child.func.attr)
        return calls

    def check_method_security(self, node: ast.FunctionDef) -> List[str]:
        security_issues = []
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                if isinstance(child.func, ast.Name):
                    if child.func.id in ["eval", "exec", "input"]:
                        security_issues.append(
                            f"Dangerous function call: {child.func.id}"
                        )
            if isinstance(child, ast.Assign):
                if isinstance(child.value, ast.Constant):
                    if any(
                        word in str(child.value.value).lower()
                        for word in ["password", "secret", "key"]
                    ):
                        security_issues.append(
                            "Potential hardcoded credentials detected"
                        )
        return security_issues

    def generate_advanced_visualizations(self, timestamp: str):
        """Generate comprehensive visual analysis"""
        import matplotlib

        matplotlib.use("Agg")  # Set non-interactive backend for thread safety
        self.generate_class_hierarchy()
        self.generate_dependency_graph()
        self.generate_metrics_dashboard()
        self.generate_security_heatmap()
        self.generate_performance_charts()

    def generate_class_hierarchy(self):
        fig, ax = plt.subplots(figsize=(20, 15))
        for class_name, class_info in self.classes.items():
            self.class_graph.add_node(class_name)
            for parent in class_info.parent_classes:
                self.class_graph.add_edge(class_name, parent)
        if self.class_graph.nodes():
            pos = nx.spring_layout(self.class_graph, k=2, iterations=50)
            node_colors = [
                self.classes[node].metrics.complexity
                for node in self.class_graph.nodes()
            ]
            nx.draw(
                self.class_graph,
                pos,
                node_color=node_colors,
                node_size=3000,
                cmap=plt.cm.viridis,
                with_labels=True,
                font_size=8,
                font_weight="bold",
                arrows=True,
                edge_color="gray",
                width=2,
                alpha=0.7,
                ax=ax,
            )
            norm = plt.Normalize(min(node_colors), max(node_colors))
            sm = plt.cm.ScalarMappable(cmap=plt.cm.viridis, norm=norm)
            sm.set_array([])
            fig.colorbar(sm, ax=ax, label="Complexity Score")
            plt.title("Class Hierarchy and Complexity Visualization", fontsize=16)
        plt.savefig(
            self.export_path / "class_hierarchy.png", dpi=300, bbox_inches="tight"
        )
        plt.close()

    def scan_directory(self, path: str) -> List[Path]:
        """Scans directory for supported file types recursively"""
        supported_extensions = {
            ".py": "Python",
            ".java": "Java",
            ".js": "JavaScript",
            ".ts": "TypeScript",
            ".cpp": "C++",
            ".cs": "C#",
            ".css": "CSS",
            ".html": "HTML",
        }
        files = []
        root_path = Path(path)
        for ext in supported_extensions:
            for file_path in root_path.rglob(f"*{ext}"):
                if file_path.is_file():
                    files.append(file_path)
                    logging.info(f"Found {supported_extensions[ext]} file: {file_path}")
        return files

    def generate_dependency_graph(self):
        plt.figure(figsize=(20, 15))
        pos = nx.kamada_kawai_layout(self.dependency_graph)
        edge_weights = [
            self.calculate_dependency_weight(u, v)
            for u, v in self.dependency_graph.edges()
        ]
        nx.draw(
            self.dependency_graph,
            pos,
            node_color="lightblue",
            node_size=2000,
            edge_color=edge_weights,
            edge_cmap=plt.cm.YlOrRd,
            with_labels=True,
            font_size=8,
            font_weight="bold",
            width=2,
        )
        plt.title("Dependency Network Analysis", fontsize=16)
        plt.savefig(
            self.export_path / "dependency_network.png", dpi=300, bbox_inches="tight"
        )

    def add_security_section(self, doc, results: Dict[str, Any]) -> List:
        """Add security analysis section to the PDF report"""
        elements = []
        heading = Paragraph("Security Analysis", doc.styles["CustomHeading"])
        elements.append(heading)
        elements.append(Spacer(1, 20))
        security_data = [["Class", "Critical", "High", "Medium", "Low", "Score"]]
        for class_name, class_info in self.classes.items():
            if class_info.security_metrics:
                security_data.append(
                    [
                        class_name,
                        str(class_info.security_metrics.critical_issues),
                        str(class_info.security_metrics.high_issues),
                        str(class_info.security_metrics.medium_issues),
                        str(class_info.security_metrics.low_issues),
                        str(class_info.security_metrics.security_score),
                    ]
                )
        table = Table(security_data)
        table._argW = [150, 70, 70, 70, 70, 70]
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                    ("TEXTCOLOR", (0, 1), (-1, -1), colors.black),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 10),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(table)
        elements.append(Spacer(1, 30))
        for class_name, class_info in self.classes.items():
            if class_info.security_vulnerabilities:
                vulns = Paragraph(
                    f"<b>{class_name} Vulnerabilities:</b><br/>"
                    + "<br/>".join(
                        [f"• {vuln}" for vuln in class_info.security_vulnerabilities]
                    ),
                    doc.styles["CustomBody"],
                )
                elements.append(vulns)
            elements.append(Spacer(1, 10))
        return elements

    def analyze_html_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        css_classes = re.findall(r'class=["\']([^"\']+)["\']', content)
        css_ids = re.findall(r'id=["\']([^"\']+)["\']', content)
        components = re.findall(
            r'<([a-zA-Z0-9-]+)[^>]*class=["\']([^"\']+)["\']', content
        )
        scripts = re.findall(r"<script[^>]*>(.*?)</script>", content, re.DOTALL)
        re.findall(r"<style[^>]*>(.*?)</style>", content, re.DOTALL)
        for tag, component in components:
            class_info = EnhancedClassInfo(
                name=f"{tag}-{component}", file_type="HTML", file_path="html_file"
            )
            class_info.metrics = AdvancedMetrics()
            class_info.metrics.complexity = len(re.findall(r"<[^>]+>", content))
            class_info.metrics.lines_of_code = len(content.splitlines())
            class_info.metrics.dependency_count = len(
                re.findall(r'href=["\'][^"\']+["\']|src=["\'][^"\']+["\']', content)
            )
            class_info.security_metrics = SecurityMetrics()
            class_info.security_metrics.vulnerabilities = [
                {"severity": "HIGH", "type": "xss"}
                for _ in re.findall(r"innerHTML|document\.write", content)
            ]
            class_info.performance_metrics = PerformanceMetrics()
            class_info.performance_metrics.bottlenecks = [
                {"type": "inline_script"} for _ in scripts
            ]
            class_info.quality_metrics = CodeQualityMetrics()
            class_info.quality_metrics.documentation_coverage = (
                len(re.findall(r"<!--.*?-->", content, re.DOTALL))
                / class_info.metrics.lines_of_code
                * 100
            )
            analysis_results["classes"][f"{tag}-{component}"] = class_info
        return analysis_results

    def analyze_css_content(self, content: str) -> Dict[str, Any]:
        analysis_results = {
            "classes": {},
            "metrics": {},
            "security": {},
            "performance": {},
            "quality": {},
        }
        selectors = re.findall(r"([.#][^{]+){([^}]+)}", content)
        re.findall(r"@media[^{]+{([^}]+)}", content)
        re.findall(r"@keyframes[^{]+{([^}]+)}", content)
        for selector, rules in selectors:
            class_info = EnhancedClassInfo(
                name=selector.strip(), file_type="CSS", file_path="css_file"
            )
            class_info.metrics = AdvancedMetrics()
            class_info.metrics.complexity = len(rules.split(";"))
            class_info.metrics.lines_of_code = len(content.splitlines())
            class_info.metrics.dependency_count = len(re.findall(r"@import", content))
            class_info.performance_metrics = PerformanceMetrics()
            class_info.performance_metrics.bottlenecks = [
                {"type": "complex_selector"}
                for _ in re.findall(r">[^,{]+,[^{]+{", selector)
            ]
            class_info.quality_metrics = CodeQualityMetrics()
            class_info.quality_metrics.maintainability_index = 100 - (
                class_info.metrics.complexity * 0.5
            )
            class_info.quality_metrics.code_duplication = (
                len(re.findall(selector, content)) - 1
            )
            specificity = (
                len(re.findall(r"#", selector)) * 100
                + len(re.findall(r"\.", selector)) * 10
                + len(re.findall(r"[a-zA-Z]", selector))
            )
            class_info.metrics.cognitive_complexity = specificity
            analysis_results["classes"][selector.strip()] = class_info
        return analysis_results

    def generate_metrics_dashboard(self):
        metrics_data = self.collect_metrics_data()
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(20, 15))
        complexity_data = [m["complexity"] for m in metrics_data]
        ax1.hist(complexity_data, bins=20, color="skyblue")
        ax1.set_title("Complexity Distribution")
        security_data = [m["security_score"] for m in metrics_data]
        ax2.bar(range(len(security_data)), security_data, color="lightgreen")
        ax2.set_title("Security Scores")
        perf_data = [m["performance_score"] for m in metrics_data]
        ax3.plot(perf_data, marker="o", color="orange")
        ax3.set_title("Performance Metrics")
        quality_data = [m["code_quality"] for m in metrics_data]
        ax4.scatter(range(len(quality_data)), quality_data, color="purple")
        ax4.set_title("Code Quality Metrics")
        plt.tight_layout()
        plt.savefig(self.export_path / "metrics_dashboard.png", dpi=300)

    def generate_interactive_html_report(self, results: Dict[str, Any], timestamp: str):
        template = self.load_html_template()
        report_data = {
            "timestamp": timestamp,
            "total_classes": len(self.classes),
            "metrics_summary": self.generate_metrics_summary(),
            "security_findings": self.generate_security_summary(),
            "performance_insights": self.generate_performance_summary(),
            "quality_metrics": self.generate_quality_summary(),
            "visualizations": self.get_visualization_paths(),
            "recommendations": self.generate_recommendations(),
        }
        html_content = template.render(**report_data)
        with open(self.export_path / f"interactive_report_{timestamp}.html", "w") as f:
            f.write(html_content)

    def generate_pdf_report(self, results: Dict[str, Any], timestamp: str):
        """Generate comprehensive PDF report"""
        doc = self.initialize_pdf_document()
        elements = []
        elements.extend(self.add_title_page(doc, timestamp))
        elements.extend(self.add_executive_summary(doc, results))
        elements.extend(self.add_metrics_section(doc, results))
        elements.extend(self.add_security_section(doc, results))
        elements.extend(self.add_performance_section(doc, results))
        elements.extend(self.add_quality_section(doc, results))
        elements.extend(self.add_visualization_pages(doc))
        elements.extend(self.add_recommendations_section(doc, results))
        doc.build(elements)

    def run_analysis(self, path: str):
        self.console.print("[bold blue]🚀 Class Analyzer v3.0 - TheZ[/bold blue]")
        self.console.print("[cyan]Initializing comprehensive analysis...[/cyan]")
        try:
            self.classes = {}
            self.metrics_cache = {}
            import sys

            sys.setrecursionlimit(50000)
            import cProfile

            cProfile.Profile().disable()
            files = self.scan_directory(path)
            if not files:
                self.console.print("[red]No files found to analyze![/red]")
                return
            with Progress(console=self.console, refresh_per_second=1) as progress:
                task = progress.add_task(
                    "[green]Analyzing project...", total=len(files)
                )
                for file in files:
                    try:
                        self.analyze_file(file)
                    except Exception as e:
                        logging.error(f"Error analyzing {file}: {str(e)}")
                    finally:
                        progress.update(task, advance=1)
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            self.classes = {
                name: (
                    self.convert_dict_to_class_info(info)
                    if isinstance(info, dict)
                    else info
                )
                for name, info in self.classes.items()
            }
            self.generate_advanced_visualizations(timestamp)
            self.export_advanced_results()
            self.display_analysis_summary()
            self.console.print(
                "[bold green]✨ Analysis completed successfully![/bold green]"
            )
        except Exception as e:
            self.console.print(f"[bold red]Error during analysis: {str(e)}[/bold red]")
            logging.error(f"Analysis failed: {str(e)}", exc_info=True)


def main():
    import sys

    sys.setrecursionlimit(50000)
    try:
        import cProfile

        profiler = cProfile.Profile()
        profiler.disable()
        analyzer = UltimatePowerClassAnalyzer(
            max_workers=2,
        )
        console = Console()
        
        console.print("[bold blue]🔍 Advanced Code Analyzer v3.0 - TheZ[/bold blue]")
        console.print("[bold green]Enter project path to analyze:[/bold green]")
        path = input().strip()
        with console.status(
            "[bold green]Running analysis...", spinner="dots"
        ) as status:
            results = analyzer.run_analysis(path)
            if results:
                console.print(
                    "[bold green]✨ Analysis completed successfully![/bold green]"
                )
                console.print(f"[cyan]Results saved to: {analyzer.export_path}[/cyan]")
    except Exception as e:
        console.print(f"[bold red]Analysis stopped: {str(e)}[/bold red]")
        return


if __name__ == "__main__":
    main()

# End of cleanup by TheZ